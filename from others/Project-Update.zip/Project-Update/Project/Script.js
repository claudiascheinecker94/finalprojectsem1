function newsletter(){
    var input = document.getElementById('input').value;
    var button = document.getElementById('button-addon2').value;

    if(button.clicked = 'true' && input != ''){
    alert("You have successfully signed up for our newsletter! Thanks a lot!");
    } else {
        alert("Please add an email address to sign up!");
    }
}